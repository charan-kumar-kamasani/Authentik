#!/bin/bash

echo "🚀 Starting deployment..."

# Load env variables
# Load env variables (stripping inline comments and whitespace)
export $(grep -v '^#' .env | sed 's/#.*//' | xargs)

# Check required vars
if [ -z "$SERVER_IP" ] || [ -z "$SERVER_USER" ] || [ -z "$SERVER_PASSWORD" ]; then
  echo "❌ Missing environment variables"
  exit 1
fi

# Step 1: Build project
echo "📦 Building project..."
npm install
npm run build

if [ $? -ne 0 ]; then
  echo "❌ Build failed"
  exit 1
fi

echo "✅ Build completed"

# Step 2: Compress build
echo "📁 Compressing files..."
tar --exclude='./node_modules' --exclude='./.git' --exclude='./deploy.tar.gz' -czf deploy.tar.gz .

# Step 3: Upload to server
echo "⬆️ Uploading to server..."

if ! command -v sshpass &> /dev/null; then
  echo "❌ sshpass is not installed. Please install it (e.g., 'brew install sshpass' on Mac) or use SSH keys."
  exit 1
fi

sshpass -p "$SERVER_PASSWORD" scp -o StrictHostKeyChecking=no deploy.tar.gz $SERVER_USER@$SERVER_IP:/tmp/

# Step 4: SSH and deploy
echo "🔧 Deploying on server..."

sshpass -p "$SERVER_PASSWORD" ssh -o StrictHostKeyChecking=no $SERVER_USER@$SERVER_IP << EOF

echo "📂 Creating app directory..."
mkdir -p $REMOTE_DIR

echo "🧹 Cleaning old files..."
rm -rf $REMOTE_DIR/*

echo "📦 Extracting new build..."
tar -xzf /tmp/deploy.tar.gz -C $REMOTE_DIR

cd $REMOTE_DIR

echo "📥 Installing dependencies..."
npm install --production

echo "🔄 Restarting PM2..."

pm2 delete $APP_NAME 2>/dev/null
pm2 start index.js --name $APP_NAME

pm2 save

echo "✅ Deployment successful"

EOF

# Cleanup
rm deploy.tar.gz

echo "🎉 Done!"