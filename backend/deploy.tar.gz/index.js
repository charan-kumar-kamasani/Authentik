/**
 * Entry point for the backend server.
 * Imports and starts the server from src/server.js.
 */
require('./src/server.js');
